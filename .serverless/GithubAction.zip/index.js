const https = require('https');

module.exports.main = async (event) => {
    console.log('Received event:', JSON.stringify(event, null, 2));
    
    const { repo_url, app_name, bundle_identifier } = event;
    
    // Validate required parameters
    if (!repo_url) {
        return {
            statusCode: 400,
            body: JSON.stringify({ 
                error: 'repo_url is required',
                received_params: { repo_url, app_name, bundle_identifier }
            })
        };
    }
    
    // Validate environment variables
    if (!process.env.GITHUB_TOKEN || !process.env.GITHUB_OWNER || !process.env.GITHUB_REPO) {
        return {
            statusCode: 500,
            body: JSON.stringify({ 
                error: 'Missing required environment variables: GITHUB_TOKEN, GITHUB_OWNER, or GITHUB_REPO'
            })
        };
    }
    
    const payload = {
        ref: 'main',
        inputs: { 
            repo_url,
            app_name: app_name || 'Manzz Contact App',
            bundle_identifier: bundle_identifier || 'com.manzzapp.contactapp'
        }
    };
    
    const options = {
        hostname: 'api.github.com',
        port: 443,
        path: `/repos/${process.env.GITHUB_OWNER}/${process.env.GITHUB_REPO}/actions/workflows/ios-build-deploy.yml/dispatches`,
        method: 'POST',
        headers: {
            'Authorization': `token ${process.env.GITHUB_TOKEN}`,
            'Accept': 'application/vnd.github.v3+json',
            'Content-Type': 'application/json',
            'User-Agent': 'iOS-Builder-Lambda'
        }
    };
    
    console.log('Making request to GitHub API:', options.path);
    
    return new Promise((resolve) => {
        const req = https.request(options, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
                console.log('GitHub API response status:', res.statusCode);
                console.log('GitHub API response data:', data);
                
                const success = res.statusCode === 204;
                resolve({
                    statusCode: success ? 200 : res.statusCode,
                    body: JSON.stringify({
                        message: success ? 'iOS build workflow triggered successfully' : 'Failed to trigger build workflow',
                        repo_url,
                        app_name: payload.inputs.app_name,
                        bundle_identifier: payload.inputs.bundle_identifier,
                        github_response: data || 'No response data',
                        github_status: res.statusCode,
                        success
                    })
                });
            });
        });
        
        req.on('error', (error) => {
            console.error('Request error:', error);
            resolve({
                statusCode: 500,
                body: JSON.stringify({ 
                    error: error.message,
                    type: 'request_error'
                })
            });
        });
        
        req.write(JSON.stringify(payload));
        req.end();
    });
};
